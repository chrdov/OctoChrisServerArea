local package_id = "com.OctoChris.MetalSonic"
local character_id = "com.OctoChris.Enemy.MetalSonic"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."virus")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("Metal Sonic")
    package:set_description("Foreign entity data has appeared. Sprites by CyberShadow.")
    package:set_speed(5)
    package:set_attack(50)
    package:set_health(2000)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    local texPath = _modpath.."BG.png"
    local animPath = _modpath.."BG.animation"
    mob:set_background(texPath, animPath, 0.0, 0.0)
    mob:stream_music(_modpath.."music.mid", 0, 0)

	mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
end