nonce = function() end

local frame_data = make_frame_data({
	{ 1, 0.033 }, { 2, 0.033 }, { 3, 0.033 }, { 4, 0.416 }
})
--HUGE THANK YOU TO JAMES AND ALRYSC FOR GETTING THE FX TO WORK!!!!
local DAMAGE = 150

local AUDIO = Engine.load_audio(_folderpath.."bowl.ogg")
local AUDIO_FIRE = Engine.load_audio(_folderpath .. "bowl.ogg")
local AUDIO_HIT = Engine.load_audio(_folderpath .. "bowl_pin.ogg")
local AUDIO_HIT2 = Engine.load_audio(_folderpath .. "hitsound.ogg")

local TEXTURE = Engine.load_texture(_folderpath .. "spell_zapring.png")
function package_init(package) 
    package:declare_package_id("DJ.bowling.4")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({"I"})

    local props = package:get_card_props()
    props.shortname = "DRKBWLG"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Break
    props.description = "BREAK ANKLES!"
	props.long_description ="DEMOLISH THEIR ANKLES WITH BOWLING!"
	props.card_class = CardClass.Dark
	props.limit = 1
end

local chip = {}
function chip.card_create_action(player, props)
    print("in create_card_action()!")
    local action = Battle.CardAction.new(player, "PLAYER_SWORD")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		self:add_anim_action(2, function()
			local hilt = self:add_attachment("HILT")
			local hilt_sprite = hilt:sprite()
			hilt_sprite:set_texture(user:get_texture())
			hilt_sprite:set_layer(-4)
			hilt_sprite:enable_parent_shader(true)

			local hilt_anim = hilt:get_animation()
			hilt_anim:copy_from(user:get_animation())
			hilt_anim:set_state("HAND")
		end)
		self:add_anim_action(3, function()
			local cannonshot = create_zap(player, props)
			local tile = user:get_tile(user:get_facing(), 1)
			player:get_field():spawn(cannonshot, tile)
		end)
	end


	
	return action --its like a output value

end






function create_zap(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:highlight_tile(Highlight.Solid)
	local direction = user:get_facing()
	spell:set_facing(direction)
	local actual_props = HitProps.new(
		DAMAGE,
		Hit.Impact | Hit.Flinch | Hit.Breaking | Hit.Drag,
		Element.Break,
		user:get_context(),
		Drag.new(direction, 1)
        )
    
		spell:set_hit_props(actual_props)
		spell.slide_started = false
		
		function create_after_image(entity, animation_state)--the cool part about fading
            local fx = Battle.Artifact.new()
			local sprite = fx:sprite()--define sprites
			sprite:set_texture(TEXTURE, false)--should be here(?)
            --fx:sprite():set_texture(entity:sprite():get_texture(),false)
			fx:get_animation():copy_from(entity:get_animation())
			
            fx:get_animation():set_state(animation_state)
            fx.fade = 255
            fx.offset = entity:get_tile_offset()
			fx:set_facing(entity:get_facing())

		
			
			fx:get_animation():refresh(sprite)--needs the define to work
			--^putting this in the below's function WILL break it! this needs to say in its "lane"
            fx.update_func = function(self, dt)--i belive like a input?
                if self.fade <= 50 then--what do you do?, seems like also the speed when it fades??
                    --self:refresh() wont work!
					self:erase()
					self:set_color(Color.new(221,160,221,self.fade))--assume color?yes
                     return
					 --self:refresh(sprite)also doesnt work!
                end
        
                self.fade = self.fade - 10 --speed of how fast it fades
                self:set_color(Color.new(221,160,221,self.fade))--assume color?yes
                
            end

            fx:set_offset(fx.offset.x, fx.offset.y)
            
        
            return fx--like a output
        end


			
		
			spell:set_offset(spell:sprite():get_offset().x, spell:sprite():get_offset().y)--what do u even do??? this is actual ball

			

			
		

		spell.attack_func = function(self, other) 
			
		
		end
		
		spell.collision_func = function(self, other)
			Engine.play_audio(AUDIO_HIT, AudioPriority.Highest)
			Engine.play_audio(AUDIO_HIT2, AudioPriority.High)
			
			
		end
		
		spell.delete_func = function(self) 
		end

		spell.can_move_to_func = function(tile)
			Engine.play_audio(AUDIO, AudioPriority.High)
			return true
		end

		-- somehwere else aka bowling ball update, predicting where the problem relies somwhere here!
		spell.update_func = function(self, dt)
			self:get_field():spawn(create_after_image(self, "DEFAULT"), self:get_tile())
			if not self:get_tile() or self:get_tile():is_edge() then self:delete() end

			self:get_tile():attack_entities(self)
			local dest = self:get_tile(direction, 1)
			local ref = self
			if self:is_moving() == false then
				self:slide(dest, frames(3), frames(0), ActionOrder.Voluntary, function() ref.slide_started = true end)
			end
		end
			local sprite = spell:sprite() -- unpack sprite from our spell object "box"
			sprite:set_layer(-2)
			-- Now we have a reference to the sprite data, we can set/get the texture
			sprite:set_texture(TEXTURE, false)
			
			local fx_anim = spell:get_animation()
			fx_anim:load(_folderpath .. "spell_zapring.animation")
			fx_anim:set_state("DEFAULT")
			
			fx_anim:refresh(sprite)--needs the define to work

			fx_anim:set_playback(Playback.Loop)
			-- ... the rest of your logic
			
		
			
			
			
		
		
		
		

		return spell
	end
	
return chip