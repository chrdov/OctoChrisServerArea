nonce = function() end

local DAMAGE = 150
local BUSTER_TEXTURE = Engine.load_texture(_folderpath.."corn.png")
local BURST_TEXTURE = Engine.load_texture(_folderpath.."cornblast.png")
local BURST_ANIM = _folderpath.."cornblast.animation"
local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")
local HIT_SOUND = Engine.load_audio(_folderpath.."cornhit.ogg")

function package_init(package) 
    package:declare_package_id("com.ipc.card.darkcorn")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({"C"})

    local props = package:get_card_props()
    props.shortname = "DarkCorn"
    props.damage = DAMAGE
    props.time_freeze = false
    props.card_class = CardClass.Dark
    props.element = Element.Wood
    props.description = "DAMAGES ENEMY WITH CORN"
    props.long_description = "DAMAGES ENEMY WITH CORN"
end

local frame1 = { 1, 0.17 }
local frame2 = { 1, 0.102 }
local frame3 = { 1, 0.17 }
local frame_data = make_frame_data({
	frame1, frame2, frame3
})

local chip = {}
function chip.card_create_action(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_folderpath.."corn.animation")
		buster_anim:set_state("DEFAULT")
		buster_anim:on_frame(3, function()
			local cornshot = create_attack(user, props)
			local tile = get_first_enemy(user, user:get_tile(user:get_facing(), 1))
			if(tile ~= nil) then
			actor:get_field():spawn(cornshot, tile)
			end
		end)
		

	end
    return action
end

--Corn can spread to next tiles.
function spread_corn(tile, user, props)
	
	local nexttile = check_if_enemy_present(user, tile:get_tile(user:get_facing(), 1))
	if(nexttile ~= nil) then
		local cornshot = create_attack(user, props)
	user:get_field():spawn(cornshot, nexttile)
	end
	local nexttile = check_if_enemy_present(user, tile:get_tile(Direction.join(user:get_facing(), Direction.Up), 1))
	if(nexttile ~= nil) then
		local cornshot = create_attack(user, props)
	user:get_field():spawn(cornshot, nexttile)
	end
	local nexttile = check_if_enemy_present(user, tile:get_tile(Direction.join(user:get_facing(), Direction.Down), 1))
	if(nexttile ~= nil) then
		local cornshot = create_attack(user, props)
	user:get_field():spawn(cornshot, nexttile)
	end
end


-- check if enemy on given tile.
function check_if_enemy_present(user, tile)
	if(tile:is_edge()) then
		return nil
	else
		if(#tile:find_entities(filter)>=1) then
			return tile
		else
			return nil
		end
	end
end

--get first enemy in line of sight
function get_first_enemy(user, tile)
	
	if(tile:is_edge()) then
		return nil
	else
		if(#tile:find_entities(filter)>=1) then
			return tile
		else
			return get_first_enemy(user, tile:get_tile(user:get_facing(), 1))
		end
	end

end

--filter function to only consider characters or obstacles
function filter(ent)  
	if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end 
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
    spell:set_hit_props(
        HitProps.new(
            DAMAGE, 
            Hit.Impact, 
            Element.Wood,
            user:get_context(),
            Drag.None
        )
    )

		spell.do_once = true


	spell.update_func = function(self, dt) 
		spell:get_current_tile():attack_entities(self)
        if(spell.do_once) then
			
			local sprite = spell:sprite()
			sprite:set_texture(BURST_TEXTURE)
			local animation = spell:get_animation()
			animation:load(BURST_ANIM)
			animation:set_state("DEFAULT")
			animation:refresh(sprite)
			animation:on_frame(4, function()
				local hitbox = Battle.Hitbox.new(spell:get_team())
				hitbox:set_hit_props(spell:copy_hit_props())
				spell:get_field():spawn(hitbox, spell:get_current_tile())
				spell:get_current_tile():set_state(TileState.Poison)
			end)
			animation:on_frame(8, function()
				local hitbox = Battle.Hitbox.new(spell:get_team())
				hitbox:set_hit_props(spell:copy_hit_props())
				spell:get_field():spawn(hitbox, spell:get_current_tile())
				spell:get_current_tile():set_state(TileState.Poison)
				spread_corn(spell:get_current_tile(), user, props)
			end)
			animation:on_complete(function () 
				self:delete()
			end)
			spell:sprite():set_layer(-1)
			spell.do_once = false
		end
        
    end
	spell.collision_func = function(self, other)
	end
    
    spell.delete_func = function(self)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
        return true
    end
            spell.attack_func = function()
                Engine.play_audio(HIT_SOUND, AudioPriority.Low)
                hasHit = true
            end

	Engine.play_audio(AUDIO, AudioPriority.High)
	return spell
end

return chip