local BUSTER_TEXTURE = Engine.load_texture(_modpath .. "Effects/CannonSeries.png")
local AUDIO = Engine.load_audio(_modpath .. "Sounds/Cannon.ogg")

local chip = {}

chip.card_create_action = function(user)
	local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	local frame1 = { 1, 0.1 }
	local frame2 = { 2, 0.1 }
	local frame3 = { 3, 0.05 }
	local frame4 = { 4, 0.05 }
	local frame5 = { 5, 0.05 }
	local frame6 = { 6, 0.02 }
	local frame7 = { 7, 0.02 }
	local frame8 = { 8, 0.02 }
	local frame9 = { 9, 0.0165 }
	local frame_sequence = make_frame_data({ frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9 })
	local original_offset = user:get_offset()
	action:override_animation_frames(frame_sequence)
	action:set_lockout(make_animation_lockout())
	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(BUSTER_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(_modpath .. "Effects/cannon.animation")
		buster_anim:set_state("Cannon3")

		self:add_anim_action(1, function()
			user:toggle_counter(true)
		end)

		self:add_anim_action(3, function()
			local recoil_component = Battle.Component.new(user, Lifetimes.Battlestep)
			recoil_component.offset_goal = -12
			if user:get_facing() == Direction.Left then recoil_component.offset_goal = 12 end
			recoil_component.goal_offset_x = original_offset.x + recoil_component.offset_goal
			recoil_component.offset_increment = -4
			if user:get_facing() == Direction.Left then recoil_component.offset_increment = 4 end
			recoil_component.owner = user
			recoil_component.update_func = function(self, dt)
				local offset = self.owner:get_offset()
				if offset.x == self.goal_offset_x then
					self:eject()
				else
					self:get_owner():set_offset(offset.x + self.offset_increment, offset.y)
				end
			end
			user:register_component(recoil_component)
		end)

		self:add_anim_action(6, function()
			user:toggle_counter(false)
			local cannonshot = create_attack(user)
			local tile = user:get_tile(user:get_facing(), 1)
			user:get_field():spawn(cannonshot, tile)
		end)

		self:add_anim_action(9, function()
			user:set_offset(original_offset.x, original_offset.y)
		end)
	end
	action.action_end_func = function(self)
		user:toggle_counter(false)
		user:set_offset(original_offset.x, original_offset.y)
	end
	return action
end

function create_attack(user)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell.slide_started = false
	spell:set_hit_props(
		HitProps.new(
			180,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.None,
			user:get_context(),
			Drag.None
		)
	)
	spell.update_func = function(self, dt)
		self:get_current_tile():attack_entities(self)
		if self:is_sliding() == false then
			if self:get_current_tile():is_edge() and self.slide_started then
				self:delete()
			end

			local dest = self:get_tile(spell:get_facing(), 1)
			local ref = self
			self:slide(dest, frames(1), frames(0), ActionOrder.Voluntary,
				function()
					ref.slide_started = true
				end
			)
		end
	end
	spell.collision_func = function(self, other)
		self:delete()
	end
	spell.attack_func = function(self, other)
	end

	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)
	return spell
end

return chip
