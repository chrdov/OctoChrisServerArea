local AUDIO = Engine.load_audio(_modpath .. "Sounds/DollThunder.ogg")

local chip = {}

local function create_thunder(user) --This defines the actual damage hitbox; makes sure that you only have User OR Actor and Props here. Not both Actor + User, Props
    local spell = Battle.Spell.new(user:get_team()) --Required to define the actual spell being referenced, and sets the team to that of the user
    spell:set_hit_props(--calls back to the hit props in funciton package_init(package) above
        HitProps.new(--needed to work
            150,
            --looks at damage above, and copies it; needs to be done in this format to be boostable by 2x effects / atk+ chips
            Hit.Impact | Hit.Flinch | Hit.Flash,
            --Impact = needs to actually collide with something to damage, Stun = Paralyze, Flash = makes them in the Invis like state
            Element.Elec, --looks at the Element defined above and copies it
            user:get_context(), --looks at the user of the chip to get context for other things such as direction
            Drag.None--you do not push the target around when hit
        )
    )
    local tile_array = {}
    local self_tile = user:get_tile()
    local y = self_tile:y()
    local x = self_tile:x()
    local increment = 1
    local field = user:get_field()
    if user:get_facing() == Direction.Left then increment = -1 end
    for i = 1, 6, 1 do
        local prospective_tile = field:tile_at(x + (i * increment), y)
        if prospective_tile and not prospective_tile:is_edge() then
            table.insert(tile_array, prospective_tile)
        end
    end
    spell.has_spawned = false --makes a note on if the spell has gone through yet
    spell.tile = nil
    spell.on_spawn_func = function(self)
        if self.tile == nil then self.tile = self:get_tile() end
        self.has_spawned = true
    end
    spell.attack_once = true
    spell.update_func = function(self, dt)
        if self.attack_once then
            for i = 1, #tile_array, 1 do
                local hitbox = Battle.SharedHitbox.new(self, 0.4)
                hitbox:set_hit_props(self:copy_hit_props())
                field:spawn(hitbox, tile_array[i])
            end
            self.attack_once = false
        end
        for k = 1, #tile_array, 1 do
            tile_array[k]:highlight(Highlight.Solid)
        end
        self.tile:attack_entities(self)
    end
    return spell
end

chip.card_create_action = function(user)
    local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
    local field = user:get_field()
    local frame1 = { 1, 0.017 }
    local frame2 = { 1, 0.100 }
    local frame3 = { 2, 0.100 }
    local frames = make_frame_data(
        {
            frame1,
            frame2, frame3, frame2, frame3 }
    )
    action:override_animation_frames(frames)
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        local buster = self:add_attachment("BUSTER")
        local buster_sprite = buster:sprite()
        buster_sprite:set_texture(Engine.load_texture(_folderpath .. "attack.png", true))
        buster_sprite:set_layer(-2)

        local buster_anim = buster:get_animation()
        buster_anim:load(_folderpath .. "attack.animation", true)
        buster_anim:set_state("DEFAULT")
        buster_anim:refresh(buster_sprite)

        self.thunder = nil
        self.animate_component = nil

        self:add_anim_action(3, function()
            self.thunder = create_thunder(user)
            field:spawn(self.thunder, user:get_tile(user:get_facing(), 1))
            local bolt = buster_sprite:create_node()
            bolt:set_texture(Engine.load_texture(_folderpath .. "attack.png")) --loads the sprite sheet from the png
            local bolt_anim = Engine.Animation.new(_folderpath .. "attack.animation") --loads the animation from the .animation file
            bolt_anim:set_state("DEFAULT2")
            bolt_anim:set_playback(Playback.Loop) --loops the animation
            bolt_anim:refresh(bolt)
            self.animate_component = Battle.Component.new(user, Lifetimes.Battlestep)
            self.animate_component.update_func = function(comp, dt)
                bolt_anim:update(dt, bolt)
            end
            bolt_anim:on_complete(function()
                if self.thunder ~= nil and not self.thunder:is_deleted() then
                    self.thunder:erase()
                    self.thunder = nil
                end
                if self.animate_component ~= nil then
                    self.animate_component:eject()
                    self.animate_component = nil
                end
            end)
            user:register_component(self.animate_component)
        end)
    end
    action.action_end_func = function(self)
        if self.animate_component ~= nil then
            self.animate_component:eject()
            self.animate_component = nil
        end
        if self.thunder ~= nil and not self.thunder:is_deleted() then
            self.thunder:erase()
            self.thunder = nil
        end
    end
    Engine.play_audio(AUDIO, AudioPriority.Low)
    Engine.play_audio(AUDIO, AudioPriority.Low)
    Engine.play_audio(AUDIO, AudioPriority.Low)
    return action
end

return chip