local chip = {}

local TANKCAN_TEXTURE = Engine.load_texture(_modpath .. "Effects/tankcan.png")
local TANKCAN_ANIM = _modpath .. "Effects/tankcan.animation"
local BLAST_TEXTURE = Engine.load_texture(_modpath .. "Effects/blast.png")
local BLAST_ANIM = _modpath .. "Effects/blast.animation"
local BACKROW_BLAST = Engine.load_texture(_modpath .. "Effects/backrow_blast.png")
local BACKROW_BLAST_ANIM = _modpath .. "Effects/backrow_blast.animation"
local AUDIO = Engine.load_audio(_modpath .. "Sounds/tankcan.ogg")

local frame1 = { 1, 0.646 }
local frame_data = make_frame_data({
	frame1
})

chip.card_create_action = function(actor, props)
	print("in create_card_action()!")
	local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

	action.execute_func = function(self, user)
		local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(TANKCAN_TEXTURE, true)
		buster:sprite():set_layer(-1)

		local buster_anim = buster:get_animation()
		buster_anim:load(TANKCAN_ANIM)
		buster_anim:set_state("DEFAULT")
		buster_anim:on_frame(8, function()
			offset = -12
			if (user:get_facing() == Direction.Left) then
				offset = 12
			end
			actor:set_offset(offset, 0)
		end)
		buster_anim:on_frame(9, function()
			local blast = create_attack(user, props)
			Engine.play_audio(AUDIO, AudioPriority.Highest)
			local tile = get_first_enemy(user, user:get_tile(user:get_facing(), 1))
			if (tile ~= nil) then
				actor:get_field():spawn(blast, tile)
			else
				local back_row = 6
				if (user:get_facing() == Direction.Left) then
					back_row = 1
				end
				local back_row_center_tile = user:get_field():tile_at(back_row, user:get_tile():y())
				create_basic_effect(user:get_field(), back_row_center_tile, BACKROW_BLAST, BACKROW_BLAST_ANIM, "DEFAULT")
				actor:shake_camera(10, 0.5)

				actor:get_field():spawn(blast, back_row_center_tile)
				local tile_up = back_row_center_tile:get_tile(Direction.Up, 1)
				local tile_down = back_row_center_tile:get_tile(Direction.Down, 1)
				back_row_center_tile:set_state(TileState.Cracked)
				if (not tile_up:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_up)
					tile_up:set_state(TileState.Cracked)
				end
				if (not tile_down:is_edge()) then
					local blast = create_attack(user, props)
					actor:get_field():spawn(blast, tile_down)
					tile_down:set_state(TileState.Cracked)
				end
			end
		end)
		buster_anim:on_frame(10, function()
			actor:set_offset(0, 0)
		end)
	end

	action.on_action_end_func = function(self)
		actor:set_offset(0, 0)
	end

	return action
end

--get first enemy in line of sight
function get_first_enemy(user, tile)

	if (tile:is_edge()) then
		return nil
	else
		if (#tile:find_entities(filter) >= 1) then
			return tile
		else
			return get_first_enemy(user, tile:get_tile(user:get_facing(), 1))
		end
	end

end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
	local fx = Battle.Artifact.new()
	fx:set_texture(hit_texture, true)
	local fx_sprite = fx:sprite()
	fx_sprite:set_layer(-3)
	local fx_anim = fx:get_animation()
	fx_anim:load(hit_anim_path)
	fx_anim:set_state(hit_anim_state)
	fx_anim:refresh(fx_sprite)
	fx_anim:on_complete(function()
		fx:erase()
	end)
	field:spawn(fx, tile)
	return fx
end

--filter function to only consider characters or obstacles
function filter(ent)
	if ent:get_health() <= 0 then return false end
	if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end
end

function create_attack(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell.slide_started = false
	local direction = user:get_facing()
	spell:set_hit_props(
		HitProps.new(
			200,
			Hit.Impact | Hit.Drag | Hit.Flinch,
			Element.None,
			user:get_context(),
			Drag.new(direction, 6)
		)
	)
	spell.do_once = true
	spell.update_func = function(self, dt)
		if (spell.do_once) then
			spell:get_current_tile():attack_entities(self)
			local sprite = spell:sprite()
			sprite:set_texture(BLAST_TEXTURE)
			local animation = spell:get_animation()
			animation:load(BLAST_ANIM)
			animation:set_state("DEFAULT")
			animation:refresh(sprite)
			animation:on_complete(function()
				self:delete()
			end)
			spell.do_once = false
		end
	end
	spell.collision_func = function(self, other)
	end

	spell.delete_func = function(self)
		self:erase()
	end

	spell.can_move_to_func = function(tile)
		return true
	end

	return spell
end

return chip